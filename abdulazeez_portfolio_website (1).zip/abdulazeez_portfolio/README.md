# Abdulazeez Abdullah — Portfolio

A responsive, static portfolio website built from the supplied resume.

## Files
- `index.html` — page content and structure
- `style.css` — responsive styling
- `script.js` — mobile navigation and current-year footer

## Run locally
Open `index.html` in a browser. For local development, you can also run:
`python -m http.server 8000`
Then visit `http://localhost:8000`.

## Before publishing
1. Review the education details and confirm the exact status/title of the Ph.D. entry.
2. Add only verified project examples, public work samples, and professional profile links.
3. Consider adding a downloadable PDF resume and a professional headshot if desired.

The site intentionally does not invent project case studies, client outcomes, profile links, or metrics absent from the resume.
